package com.jh.cs4301_asg3_v2;

public class ContactList {
    private String firstName, lastName, phoneNum, bod, foc;
    int uniqueID;

    public ContactList(){

    }

    public ContactList(int id, String fn, String ln, String pn, String bod, String foc){
        this.uniqueID = id;
        this.firstName = fn;
        this.lastName = ln;
        this.phoneNum = pn;
        this.bod = bod;
        this.foc = foc;
    }

    public int getUniqueID() {
        return uniqueID;
    }

    public String getBod() {
        return bod;
    }

    public void setBod(String bod) {
        this.bod = bod;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public void setFoc(String foc) {
        this.foc = foc;
    }

    public String getFoc() {
        return foc;
    }
}
