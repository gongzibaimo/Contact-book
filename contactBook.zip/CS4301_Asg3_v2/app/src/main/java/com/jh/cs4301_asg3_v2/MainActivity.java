package com.jh.cs4301_asg3_v2;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/*
* Assignment 3:add contact
* Student Name: Jiao Huang, Alex Gao
* Student ID: jxh170330, axg156230
* */
public class MainActivity extends AppCompatActivity {
    // define array contactList
    ListView list;
    String[] contactList;
    // initialize count = 0
    int count = 0;

    InputStream inputStreamCounter;
    BufferedReader bufferedReaderCounter;

    InputStream inputStreamLoader;
    BufferedReader bufferedReaderLoader;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = (ListView)findViewById(R.id.list);
        // define actionbar
        ActionBar actionBar = getSupportActionBar();
        getSupportActionBar().setTitle("title");
        String title = actionBar.getTitle().toString();

        //counter
        inputStreamCounter = this.getResources().openRawResource(R.raw.contactlist);
        bufferedReaderCounter = new BufferedReader(new InputStreamReader(inputStreamCounter));
        inputStreamLoader = this.getResources().openRawResource(R.raw.contactlist);
        bufferedReaderLoader = new BufferedReader(new InputStreamReader(inputStreamLoader));

        // count numbers of rows or lines in txt file
        try{
            while(bufferedReaderCounter.readLine() != null){
                count++;
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        // load lines into String array
        contactList = new String[count];
        try{
            for(int i = 0; i <count; i++){
                contactList[i] = bufferedReaderLoader.readLine();
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        // array adapter to make the data adapt to the listView, which means the data import into the listView
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
                android.R.id.text1, contactList);

        list.setAdapter(adapter);

        // set onclick listener for the listView, when user click on each row of the listView, go to next page
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                for(int i = 0; i <count; i++){
                    if(position == i){
                        Intent myintent = new Intent(view.getContext(), CostumerInfo.class);
                        startActivityForResult(myintent, i);
                    }
                }

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public void onComposeAction(MenuItem add){
        startActivity(new Intent(this, CostumerInfo.class));
    }
}
