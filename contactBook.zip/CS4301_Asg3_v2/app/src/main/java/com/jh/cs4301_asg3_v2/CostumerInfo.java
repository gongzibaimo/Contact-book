package com.jh.cs4301_asg3_v2;

import android.app.DatePickerDialog;
import android.app.FragmentManager;
import android.content.Intent;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.FrameLayout;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
/*
 * Assignment 3:add contact
 * Student Name: Jiao Huang, Alex Gao
 * Student ID: jxh170330, axg156230
 * */

// class extend datepicker dialog
public class CostumerInfo extends AppCompatActivity implements DatePickerDialog.OnDateSetListener{

    EditText edit_firstname, edit_lastname, edit_phonenum;
    private Calendar startDate;
    public boolean bdclick = false;
    public boolean fclick = false;
    FrameLayout dob_frame, firstContact_frame;
    DateFirstContact dateFirstContact, dateOfContact;
    FragmentManager fragmentManager;
    View myView;
    ArrayList<ContactList> saveList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_costumer_info);

        EditText dob = (EditText) findViewById(R.id.BirthDate_et);
        Button back = (Button)findViewById(R.id.back);
        edit_firstname = findViewById(R.id.firstName_editText);
        edit_lastname = findViewById(R.id.lastName_et);
        edit_phonenum = findViewById(R.id.phoneNumber_et);

        // when user click go back button, it brings you from second page to first page
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CostumerInfo.this, MainActivity.class);
                startActivity(intent);
            }
        });

        // calendar event
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bdclick = true;
                DatePickerFragment frag = new DatePickerFragment();
                frag.isBirthday = true;
                DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(), "date picker");
            }
        });

    }


    public void onEDClick(View view){
        fclick = true;
        DatePickerFragment frag = new DatePickerFragment();
        frag.isFirstday = true;

        DialogFragment datePicker = new DatePickerFragment();
        datePicker.show(getSupportFragmentManager(), "date picker");
    }

    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        String currentDateString = DateFormat.getDateInstance(DateFormat.FULL).format(c.getTime());
        DatePickerFragment frag = new DatePickerFragment();

        EditText dofc = (EditText) findViewById(R.id.dofc_et);
        EditText dob = (EditText) findViewById(R.id.BirthDate_et);
       // if(frag.isFirstday == true){
            dofc.setText(currentDateString);
       // }
       // if (frag.isBirthday == true) {
            dob.setText(currentDateString);
       // }

        startDate = Calendar.getInstance();

    }
}
